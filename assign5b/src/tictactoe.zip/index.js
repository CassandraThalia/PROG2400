import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Game from './Game.js';
 
// ========================================

ReactDOM.render(
<Game />,
document.getElementById('root')
);


//Resources:
//https://medium.com/@thekevinwang/react-%EF%B8%8F-tic-tac-toe-%EF%B8%8F%E2%83%A3-extras-88e68f025772